控制台：https://console.bce.baidu.com/ai/?fromai=1#/ai/imagerecognition/overview/index

接口说明：https://ai.baidu.com/ai-doc/IMAGERECOGNITION/rk3bcxg71

